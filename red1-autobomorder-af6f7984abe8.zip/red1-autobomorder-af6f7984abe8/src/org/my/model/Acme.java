package org.my.model;

public class Acme {

}
